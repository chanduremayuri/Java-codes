//for loop
package Package1;

public class Display {
public static void main(String[] args) {
	int i;
	for(i=1;i<=10;i++){
		System.out.println("programmer!!\n");
	}
}
}
