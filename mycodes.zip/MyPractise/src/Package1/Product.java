package Package1;
import java.util.*;
class Product {
public static void main(String args[]){
	int a,b,result;
	
	System.out.println("Enter two no:");
	Scanner sc =new Scanner(System.in);
	a= sc.nextInt();
	b=sc.nextInt();
	result=a*b;
	System.out.println("product of two no:"+result);
	
}
}
