package Package1;
import java.util.*;

public class Square {
	public static void main(String[] mayuri){
		int a,b;
		Scanner sc=new Scanner(System.in);
		System.out.println("\nEnter the no:");
		a=sc.nextInt();
		b=a*a;
		System.out.println("\nThe square of the entered no is "+b);
	}

}
